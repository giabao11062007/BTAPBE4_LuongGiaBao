Môn học: Web BE Development
Sinh viên thực hiện: Lương Gia Bảo
Mã số sinh viên: 25DH110287
Tên Zip: 25DH110287_LuongGiaBao.zip

DỰ ÁN XÂY DỰNG WEBSITE BÁN HÀNG BẰNG ASP.NET MVC 5 & ENTITY FRAMEWORK:
1. Quản lý Danh mục (CRUD Category):
   - Controller: CategoriesController.cs
   - Optimization: Dùng Partial View (PVCreateEditCategory.cshtml) và tối ưu hóa hàm GET (Details/Edit/Delete).
2. Quản lý Sản phẩm (CRUD Product):
   - Controller: ProductsController.cs
   - Optimization: Dùng Partial Views (PVCreateEditProduct.cshtml, PVProductInfo.cshtml, PVListProduct.cshtml).
   - Upload Ảnh: Thuộc tính NotMapped UploadImg trong Product.cs lưu vào ~/Content/images/.
3. Tìm kiếm, Sắp xếp và Phân trang (Product Search, Sort & Pagination):
   - ViewModel: ProductSearchVM.cs
   - Tìm kiếm từ khóa (SearchTerm) & Khoảng giá (MinPrice, MaxPrice).
   - Sắp xếp tăng/giảm theo tên và giá (SortOrder).
   - Phân trang kết quả sử dụng thư viện PagedList.Mvc.
4. Layout & Giao diện Admin:
   - Admin Layout: _AdminLayout.cshtml

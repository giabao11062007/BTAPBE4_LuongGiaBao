using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;
using 25DH110287_LuongGiaBao.Models;

namespace 25DH110287_LuongGiaBao.Models.ViewModel
{
    public class ProductSearchVM
    {
        public string SearchTerm { get; set; }

        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }

        public string SortOrder { get; set; }

        public int PageNumber { get; set; } = 1;

        public int PageSize { get; set; } = 10;

        public IPagedList<Product> Products { get; set; }
    }
}
